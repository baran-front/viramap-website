// components/Home/HeroSection/index.ts
export { default } from './HeroSection';