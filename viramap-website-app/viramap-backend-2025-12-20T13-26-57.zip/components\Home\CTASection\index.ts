// components/home/CTASection/index.ts
export { default } from './CTASection';