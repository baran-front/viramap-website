// components/home/DynamicSlider/index.ts
export { default } from './DynamicSlider';