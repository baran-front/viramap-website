// components/lib/fetches/index.ts
/**
 * Export مرکزی برای تمام توابع fetch
 */

export * from "./hero";

