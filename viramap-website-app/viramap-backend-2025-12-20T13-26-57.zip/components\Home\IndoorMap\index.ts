// components/home/IndoorMap/index.ts
export { default } from './IndoorMap';