// components/layout/Footer/index.ts
export { default } from './Footer';