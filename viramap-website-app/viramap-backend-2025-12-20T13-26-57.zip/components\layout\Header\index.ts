// components/layout/Header/index.ts
export { default } from './Header';