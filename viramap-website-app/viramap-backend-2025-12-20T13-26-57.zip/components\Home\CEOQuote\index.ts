// components/home/CEOQuote/index.ts
export { default } from './CEOQuote';